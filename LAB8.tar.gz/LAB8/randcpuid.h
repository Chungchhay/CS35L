extern _Bool rdrand_supported (void);
