#include <stdio.h>
#include <math.h>

int main() 
{
  printf("Here is the result : %.17g", cos(sqrt(3.0)));
  return 0;
}
